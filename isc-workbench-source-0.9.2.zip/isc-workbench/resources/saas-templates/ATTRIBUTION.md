# SaaS project templates

Connector and customizer project templates are reproduced from the official
SailPoint CLI at commit `612af9560eab53ee879b565dd321cd9b4856243f`, the snapshot
referenced by the SaaS Connectivity extension reviewed for this integration.

Source: https://github.com/sailpoint-oss/sailpoint-cli/tree/612af9560eab53ee879b565dd321cd9b4856243f/cmd/connector/static

The included LICENSE.txt preserves the original license. The generated projects
have their own npm dependencies; they are not runtime dependencies of Workbench.
