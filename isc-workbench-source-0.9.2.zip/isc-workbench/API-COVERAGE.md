# Bundled API coverage

Every method/path entry in the five official ISC root specifications is included in the API Catalog. Counts below are by tag; operations with multiple tags can appear in more than one row. General API runner coverage is distinct from dedicated resource-tree UI coverage.

Snapshot: `a829aeff963ccc11578b7b26ba42c3bccada8b27`.

| Category | v2026 | v2025 | v2024 | v3 | beta |
| --- | ---: | ---: | ---: | ---: | ---: |
| Access Model Metadata | 10 | 13 | 10 | 0 | 10 |
| Access Profiles | 14 | 8 | 8 | 7 | 8 |
| Access Request Approvals | 7 | 7 | 7 | 6 | 6 |
| Access Request Identity Metrics | 1 | 1 | 1 | 0 | 1 |
| Access Requests | 11 | 11 | 11 | 5 | 7 |
| Account Activities | 2 | 2 | 2 | 2 | 2 |
| Account Aggregations | 1 | 1 | 1 | 0 | 1 |
| Account Deletion Requests | 2 | 0 | 0 | 0 | 0 |
| Account Usages | 1 | 1 | 1 | 1 | 1 |
| Accounts | 16 | 16 | 16 | 11 | 16 |
| Api Usage | 2 | 2 | 0 | 0 | 0 |
| Application Discovery | 4 | 4 | 3 | 3 | 5 |
| Approvals | 15 | 14 | 2 | 0 | 0 |
| Apps | 14 | 14 | 14 | 0 | 14 |
| Auth Profile | 3 | 3 | 3 | 0 | 3 |
| Auth Users | 2 | 2 | 2 | 2 | 0 |
| Branding | 5 | 5 | 5 | 5 | 0 |
| Certification Campaign Filters | 5 | 5 | 5 | 5 | 0 |
| Certification Campaigns | 22 | 22 | 22 | 22 | 22 |
| Certification Summaries | 4 | 4 | 4 | 4 | 0 |
| Certifications | 11 | 11 | 11 | 11 | 6 |
| Classify Source | 3 | 3 | 0 | 0 | 0 |
| Configuration Hub | 20 | 20 | 20 | 9 | 0 |
| Connector Customizers | 6 | 6 | 6 | 0 | 0 |
| Connector Rule Management | 6 | 6 | 6 | 0 | 6 |
| Connectors | 13 | 13 | 13 | 11 | 1 |
| Custom Forms | 18 | 18 | 18 | 0 | 19 |
| Custom Password Instructions | 3 | 3 | 3 | 0 | 3 |
| Custom User Levels | 9 | 9 | 0 | 0 | 0 |
| Data Access Security | 21 | 21 | 0 | 0 | 0 |
| Data Segmentation | 8 | 8 | 8 | 0 | 0 |
| Declassify Source | 1 | 1 | 0 | 0 | 0 |
| Dimensions | 8 | 8 | 8 | 0 | 0 |
| Entitlement Connections | 5 | 0 | 0 | 0 | 0 |
| Entitlements | 13 | 12 | 12 | 0 | 12 |
| Global Tenant Security Settings | 9 | 9 | 9 | 9 | 0 |
| Governance Groups | 10 | 10 | 10 | 0 | 10 |
| IAI Access Request Recommendations | 10 | 10 | 10 | 0 | 8 |
| IAI Common Access | 3 | 3 | 3 | 0 | 3 |
| IAI Message Catalogs | 0 | 0 | 0 | 0 | 1 |
| IAI Outliers | 9 | 9 | 9 | 0 | 9 |
| IAI Peer Group Strategies | 1 | 1 | 1 | 0 | 1 |
| IAI Recommendations | 3 | 3 | 3 | 0 | 3 |
| IAI Role Mining | 25 | 25 | 25 | 0 | 25 |
| Icons | 2 | 2 | 2 | 0 | 2 |
| Identities | 12 | 12 | 12 | 0 | 11 |
| Identity Attributes | 6 | 6 | 6 | 0 | 6 |
| Identity History | 11 | 11 | 11 | 0 | 11 |
| Identity Profiles | 11 | 11 | 11 | 11 | 11 |
| Intelligence | 5 | 0 | 0 | 0 | 0 |
| JIT Access | 2 | 0 | 0 | 0 | 0 |
| JIT Activations | 3 | 0 | 0 | 0 | 0 |
| Launchers | 6 | 6 | 6 | 0 | 6 |
| Lifecycle States | 6 | 6 | 6 | 6 | 2 |
| MFA Configuration | 7 | 7 | 7 | 8 | 8 |
| MFA Controller | 0 | 0 | 0 | 6 | 6 |
| Machine Account Classify | 1 | 1 | 1 | 0 | 0 |
| Machine Account Creation Request | 3 | 0 | 0 | 0 | 0 |
| Machine Account Mappings | 4 | 4 | 4 | 0 | 0 |
| Machine Account Subtypes | 8 | 0 | 0 | 0 | 0 |
| Machine Accounts | 9 | 9 | 3 | 0 | 0 |
| Machine Classification Config | 3 | 3 | 3 | 0 | 0 |
| Machine Identities | 7 | 7 | 5 | 0 | 0 |
| Managed Clients | 7 | 7 | 6 | 6 | 2 |
| Managed Cluster Types | 5 | 5 | 5 | 0 | 0 |
| Managed Clusters | 8 | 8 | 8 | 7 | 4 |
| Multi-Host Integration | 14 | 14 | 13 | 0 | 13 |
| Non-Employee Lifecycle Management | 32 | 32 | 32 | 32 | 32 |
| Notifications | 18 | 15 | 15 | 0 | 15 |
| OAuth Clients | 5 | 5 | 5 | 5 | 5 |
| Org Config | 3 | 3 | 3 | 0 | 3 |
| Parameter Storage | 8 | 8 | 0 | 0 | 0 |
| Password Configuration | 3 | 3 | 3 | 3 | 3 |
| Password Dictionary | 2 | 2 | 2 | 2 | 2 |
| Password Management | 4 | 4 | 4 | 3 | 4 |
| Password Policies | 5 | 5 | 5 | 5 | 5 |
| Password Sync Groups | 5 | 5 | 5 | 5 | 5 |
| Personal Access Tokens | 4 | 4 | 4 | 4 | 4 |
| Privilege Criteria | 5 | 5 | 0 | 0 | 0 |
| Privilege Criteria Configuration | 3 | 3 | 0 | 0 | 0 |
| Public Identities | 1 | 1 | 1 | 1 | 0 |
| Public Identities Config | 2 | 2 | 2 | 2 | 2 |
| Reports Data Extraction | 4 | 4 | 4 | 4 | 0 |
| Requestable Objects | 1 | 1 | 1 | 1 | 1 |
| Role Insights | 9 | 9 | 9 | 0 | 9 |
| Role Propagation | 6 | 6 | 0 | 0 | 0 |
| Roles | 16 | 16 | 16 | 7 | 8 |
| SIM Integrations | 7 | 7 | 7 | 0 | 7 |
| SOD Policies | 17 | 17 | 17 | 17 | 16 |
| SOD Violations | 2 | 2 | 2 | 2 | 1 |
| SP-Config | 7 | 7 | 7 | 0 | 7 |
| Saved Search | 6 | 6 | 6 | 6 | 0 |
| Scheduled Search | 6 | 6 | 6 | 6 | 0 |
| Search | 4 | 4 | 4 | 4 | 0 |
| Search Attribute Configuration | 5 | 5 | 5 | 5 | 5 |
| Segments | 5 | 5 | 5 | 5 | 5 |
| Service Desk Integration | 10 | 10 | 10 | 10 | 10 |
| Shared Signals Framework (SSF) | 10 | 10 | 0 | 0 | 0 |
| Source Usages | 2 | 2 | 2 | 2 | 2 |
| Sources | 60 | 52 | 51 | 26 | 43 |
| Suggested Entitlement Description | 15 | 7 | 7 | 0 | 7 |
| Tagged Objects | 8 | 8 | 8 | 8 | 8 |
| Tags | 4 | 4 | 4 | 0 | 4 |
| Task Management | 3 | 5 | 5 | 0 | 5 |
| Tenant | 1 | 1 | 1 | 0 | 1 |
| Tenant Context | 2 | 2 | 2 | 0 | 0 |
| Transforms | 5 | 5 | 5 | 5 | 5 |
| Triggers | 10 | 10 | 10 | 0 | 10 |
| UI Metadata | 2 | 2 | 2 | 0 | 2 |
| Work Items | 13 | 13 | 13 | 13 | 13 |
| Work Reassignment | 9 | 9 | 9 | 0 | 9 |
| Workflows | 19 | 19 | 18 | 18 | 18 |
