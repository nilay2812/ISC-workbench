# ISC Workbench

A standalone VS Code extension for SailPoint Identity Security Cloud, built for Nilay Mani. It combines a tenant tree and save-through JSON editing with a broad, specification-driven API explorer and a reviewed environment promotion workflow.

**Release: 0.7.1 — preview.** Independent community software; not an official SailPoint product. The installable VSIX works without installing Node, Python, or npm. VS Code **1.105.0 or later** is required.

## Install and connect

1. Download `isc-workbench-0.7.1.vsix`.
2. In VS Code, open Extensions with **Ctrl+Shift+X**. Click **… → Install from VSIX…**, then select the file.
3. Open the shield/code icon in the activity bar, or run **ISC Workbench: Open Workbench** from **Ctrl+Shift+P**.
4. Run **Add Environment**. Give it a name such as `Development` or `UAT`, and enter the API origin, for example `https://company-sb.api.identitynow.com`.
5. Enter a SailPoint PAT client ID and client secret, or a short-lived bearer token. Credentials are stored in VS Code SecretStorage, not workspace configuration.
6. Run **Test Authentication**. This checks a one-item sources read; a 403 means this check cannot establish the required source-read permission.
7. New environments start **read-only**. Use the environment’s **Toggle Environment Lock** button (or **Configure Environment → Enable writes**) to unlock it. Saving connected resource documents now writes directly to that tenant; Auto Save does too when enabled. Add each environment independently; credentials are not imported from another extension.

The original extension can remain installed: this extension has separate command names, views, and credential storage. There is no Marketplace publication or automatic update channel for this build.

## API coverage

The package includes every operation in these five official ISC OpenAPI files at the recorded commit:

| API version | Operation entries |
| --- | ---: |
| v2026 (default) | 864 |
| v2025 | 814 |
| v2024 | 718 |
| v3 | 358 |
| beta | 561 |
| **Total versioned entries** | **3,315** |

These are **versioned entries, not 3,315 distinct capabilities**. Many operations recur across releases. v2026 covers 110 API tags. The offline catalog includes request parameters, request/response schemas, descriptions, scopes, user levels, and deprecation flags. API access still depends on tenant features, licensing, permissions, and whether that version is served by your tenant.

Included areas extend beyond the dedicated resource tree: Configuration Hub, certifications/campaigns, access requests and approvals, search, accounts, machine identities, JIT access, password management, tenant settings, notifications, triggers, connectors, and the other published ISC categories.

NERM and IdentityIQ have separate products/specifications and are not included. Private/undocumented endpoints are not fabricated. Compatibility catalogs do not imply that retired endpoints remain available.

### Run any catalog operation

1. Run **Search All APIs**. The sidebar catalog is hidden by default; enable `iscWorkbench.showApiCatalog` in Settings if you want to browse it. Search matches method, path, operation ID, category, and summary.
2. Select an operation and environment. An editable JSON request opens with required parameters and a starter body.
3. Edit `path`, `query`, `headers`, and `body`. Use JSON completion from the attached schema. Starter values and examples are placeholders, not tenant-specific valid values.
4. Use **Inspect Operation Schema** for the full documented parameters, scopes, user levels, body, and response schemas. **Open Request Documentation** opens the corresponding developer page.
5. Run **Run Request**, or press **Ctrl+Alt+Enter** / **Cmd+Alt+Enter**. Writes require explicit confirmation.

You can save request JSON in your project and reopen it later. The `environmentId` binds it to your locally configured environment; update that ID or create a new request if moving to another computer. The generated `$schema` file is local to this installation; recreate the request for completion on another machine.

Supported transports: JSON, JSON Patch, multipart file upload, form URL encoding, and binary response downloads. For multipart file fields, replace the placeholder with:

```json
{"$file": "C:\\Users\\Nilay\\Downloads\\accounts.csv"}
```

On macOS/Linux, use an absolute path such as `/Users/nilay/Downloads/accounts.csv`. Each file upload asks you to confirm the local path and destination. Binary downloads prompt for a save location. Request/response size is limited to 100 MB; use filters and pagination for large datasets.

JSON responses from the general request runner redact fields with secret-like names. Resource editors and promotion files preserve configuration so it can be edited faithfully; store those files securely. The request log contains method, route template, status, duration, and request ID, not tokens, bodies, query values, or response payloads.

Basic local validation checks required fields, types, enum values, arrays, and schema alternatives. It is not a full semantic validator. Some official polymorphic schemas overlap, so exclusive `oneOf` matching, patterns, cross-field rules, and service permissions remain server-authoritative.

### Browse and edit resources

The **Environments** tree includes supported collections for sources, transforms, connector rules, workflows, identity profiles/attributes, access profiles, roles, identities, accounts, entitlements, governance groups, applications, forms, and machine identities. The collection appears only when its GET exists in the selected version.

Expand a collection, then click an object to open JSON. Environment names, collections, and resource labels sort alphabetically (case-insensitive, with natural number ordering). Offset-paginated collections are fetched and sorted before display. Configuration collections, including Sources, show all fetched rows; identities, accounts, and entitlements retain cached 50-row navigation. Collections exceeding 10,000 objects require a filtered API request. Sources request server-side name sorting too. Offsets advance by the number of records actually returned, stopping at the reported total or an empty page rather than assuming a short page is the end. Repeated pages cause an explicit error. **Find Source** performs a fresh name lookup across configured/v2025/v3/beta API versions and checks display aliases when needed; it opens matches using the returned API ID and produces diagnostics when none is found.

Unlock the environment, open a resource, edit its JSON, and press **Ctrl+S / Cmd+S**. These are connected `isc-resource:` documents, not untitled scratch files. No separate Publish action or per-save confirmation is needed. **VS Code Auto Save also writes to ISC when enabled.** Disable Auto Save if you want only manual saves.

Locked environments expose read-only files. Toggling the environment lock updates open document permissions and every save rechecks the current lock state. Resources without a supported documented JSON update endpoint remain read-only even in an unlocked tenant.

Source nodes expand into **Schemas** and **Provisioning Policies**. Their individual JSON documents follow the same save behavior. Open the source row itself to edit source settings.

Before saving, the extension validates JSON and checks that the remote resource has not changed since its last verified read. JSON Patch updates contain only changed paths, including nested fields, so editing a host does not resend an unchanged sibling password. PUT endpoints receive the edited configuration with common read-only fields removed. There is no server-wide transaction or guaranteed atomic compare-and-swap; concurrent remote updates can still race a save.

On a rejected save, VS Code reports the failure and retains the dirty document. If a network failure leaves acceptance uncertain, further saves are blocked: preserve the edited text locally, then close and reopen the resource to inspect its actual server state. Successful saves refresh the remote baseline, so you can continue editing the same tab without reopening it. No credentials or document bodies are written to request logs.

Only endpoints with a supported documented PUT or JSON Patch method use this shortcut. Specialized action endpoints and custom PATCH formats remain available through **Search All APIs**. **Create Resource** submits creation when the dialog inputs are complete, then opens the created object. No initial Ctrl+S is required. Cancel a prompt before submission to cancel creation. Later Ctrl+S/Auto Save updates the connected object.

Sources offer a selection from the tenant's connector types; the first use fetches them, subsequent uses use the cache. Refresh Connector Types reloads the choices. The owner defaults to the identity owning the authenticated PAT. If that identity cannot be resolved, creation stops with an explanation instead of assigning an arbitrary owner. This identifies the credential owner, which may differ from the human using a shared PAT.

Transforms and connector rules use the reference's MIT-licensed type templates. Complex templates may require a JSON input to complete placeholders. Required schema enum values use pickers; required string values use input prompts. Access profiles select an existing source. These are not full specialized wizards for every API: service-specific validation and additional reference configuration may still be necessary. The server remains authoritative. POST is never automatically retried; inspect tenant state after an ambiguous response before manually creating again.

Right-click a source for **Run Account Aggregation**, **Run Unoptimized Account Aggregation**, **Test Source Connection**, or **Ping Source Cluster**. These require an unlocked environment and confirmation. Action results appear as readable VS Code notifications. A returned task ID indicates submission rather than completed aggregation; notifications do not claim the background job finished. Delimited-file aggregation requires a CSV via Resource API Actions. Right-click other resources for **Resource API Actions**, which opens a bound editable API request; use Run Request to execute it.

Connector rules also offer **Open Rule Script** to edit the script separately and save it into its parent rule. Workflow rows offer **Enable Workflow** or **Disable Workflow** while unlocked. Transform JSON snippets are included.

**Identifiers:** tree labels are for display. GET/PATCH/PUT requests use the actual `id` returned by the resource API. The extension does not parse a `[source-...]` audit-event label, infer IDs from names, or use the source's connector script name as its object ID. A newly created resource opens using the ID from the creation response. **Copy Resource ID** is available on a resource's context menu. If the API omits an addressable ID, the extension asks you to refresh rather than guessing or creating it again.

The tenant icon and inline lock button both show a **closed lock when read-only** and an **open lock when writable**. Click to switch states. Collections also have a **Refresh Collection** button. This release implements the requested open/edit/save workflow; it does not claim every specialized wizard or dashboard in the reference extension.

## Promote configuration between environments

Promotion uses the official **SP-Config** export/import service. Its server-side import preview resolves supported references before applying configuration. Supported object types are discovered from the source tenant's `/sp-config/config-objects` response; the target preview is authoritative for import compatibility. A resource having an API does not automatically make it promotable through SP-Config.

1. Run **Prepare Environment Promotion**.
2. Choose distinct source and target tenants, an API version (default choice v2026), and configuration types. Optionally enter exact object names. Leaving names empty exports all objects in the chosen types.
3. Choose a new local folder. The extension exports the source selection and all target objects of the selected types for the baseline.
4. Review `comparison.json`, `source.json`, `candidate.json`, and `target-baseline.json`. Comparison labels are `CREATE`, `UNCHANGED`, or `REVIEW_UPDATE`; server preview determines what will actually import. Different tenant IDs can cause a review-update classification even when business settings match.
5. Edit **candidate.json** directly for environment-specific values, or add precise replacements to **mappings.json**, then run **Apply Promotion Mappings**. That command rebuilds the candidate from `source.json` and mappings, replacing manual candidate edits after confirmation.
6. Run **Preview Promotion**. Inspect `preview-result.json` and the VS Code comparison. Fix unresolved references and errors. Include needed dependencies in the export, or ensure they already exist in the target.
7. Run **Apply Promotion**. It checks target drift, runs a fresh server preview, opens its result, and asks you to type the exact target environment name. It checks target drift again after your review and submits import with **backup enabled**.
8. Inspect the timestamped `import-result-*.json` and `backup-*.json`. Object-level errors are reported even if the job itself reaches COMPLETE. Use **Resume or Inspect Job** if a wait was cancelled, timed out, or the window closed.

Example `mappings.json`:

```json
[
  {
    "pointer": "/objects/0/object/owner/id",
    "from": "source-owner-identity-id",
    "to": "target-owner-identity-id"
  }
]
```

Mappings use JSON Pointer, not blind string replacement. The old value must match. Choose pointers that actually exist in your export. Object metadata is preserved. Signed configuration objects cannot be edited. Lifecycle-state or other duplicate type/name combinations are rejected for comparison rather than silently matched to the wrong object.

Promotion checks source and target origins, current source signing rules, candidate scope, fresh preview results, and target snapshots. There is still a small race between the final check and import because SP-Config does not provide a transaction or compare-and-swap for the whole tenant.

**Recovery is not automatic rollback.** Imports can partially succeed. A backup supports inspection and a separately reviewed restore, but reimporting an old snapshot may not delete newly created objects. Connector passwords, workflow secrets, embedded script identifiers, and references not described by the service may need manual target configuration. NELM data is not supported by SP-Config. No automatic dependency discovery/closure is claimed; review the server preview.

## Commands

Command titles no longer carry a product prefix. Context menus name the selected item type; prompts include the selected item name.

| Workflow | Commands |
| --- | --- |
| Connections | Add Environment; Configure Environment; Toggle Environment Lock; Remove Environment; Test Authentication |
| API | Search All APIs; New API Request; Inspect Operation Schema; Open Request Documentation; Run Request |
| Resources | Refresh Environments; Create Resource; Ctrl+S / Cmd+S to save connected resources |
| Promotion | Prepare Environment Promotion; Apply Promotion Mappings; Preview Promotion; Apply Promotion; Resume or Inspect Job |
| Help | Open Workbench; Show Request Log |

## Troubleshooting

- **401:** update credentials. PAT access tokens are refreshed through the OAuth token endpoint; pasted bearer tokens need manual replacement after expiry.
- **403:** collection rows explain access was denied, rather than implying an empty list. No version fallback is attempted for denied access. Verify token scopes, the owning user's role, and feature entitlement. Using the same credentials as Postman helps isolate configuration differences.
- **404:** collection reads try documented v2025/v3/beta compatibility versions and bind successful editors to that version. If all return 404, the row explains that endpoint/feature availability remains unresolved. This cannot enable an unlicensed tenant feature.
- **429/503:** reads retry with bounded backoff and Retry-After handling. Writes and job submissions are never automatically replayed.
- **Network failure during a write:** the server may have accepted it. Inspect tenant state or the recorded job before retrying.
- **Proxy/TLS:** the extension uses Node's native HTTPS fetch and validates certificates. VS Code's `http.proxy` is not automatically wired into this build. A mandatory corporate proxy/custom certificate setup needs to be configured and tested in the extension-host environment; TLS verification is never disabled.
- **Restricted workspace:** tenant actions require VS Code Workspace Trust. Trust a folder you control.
- **After window reload:** connected resource URIs restore their tenant/resource binding and fetch a fresh baseline. Unsaved recovered edits are not a persisted concurrency baseline; recheck remote state after a restart. Saved request and promotion files can be reopened normally.

## Develop, test, and rebuild

Runtime code uses JavaScript and Node APIs without production npm dependencies. Use Node 22 or later for development.

```sh
npm ci
npm run check
npm test
npm run package
```

Press **F5** in this source folder to launch an Extension Development Host. For the optional actual VS Code smoke test, use `node scripts/host-smoke.cjs`; Linux needs a working Electron graphical/headless backend. The offline tests do not require credentials or a tenant.

Refresh the official API snapshot:

```sh
git clone https://github.com/sailpoint-oss/api-specs.git ../api-specs
python -m pip install PyYAML
npm run catalog
npm test
npm run package
```

The catalog build follows local YAML references, preserves recursive schemas, prohibits remote references during bundling, records the source commit, and stores per-version SHA-256 hashes. Check API count assertions when intentionally refreshing to a new snapshot.

### Source layout

- `src/extension.js`: VS Code commands, views, editors, schema completion, request runner.
- `src/creation.js`: local creation templates, cached connector selection, first-save submission, and persisted creation receipts.
- `src/resource-files.js`: remote filesystem, editor permissions, and save lifecycle.
- `src/core.js`: bundled catalog, shape validation, URL handling, mapping and comparison.
- `src/client.js`: OAuth, tenant HTTP transport, bounded reads, retries, job polling.
- `src/promotion.js`: export, preview, drift checks, explicit import, result/backup handling.
- `resources/`: offline official schemas, indexed operations, license, and activity icon.
- `test/`: offline core and workflow tests, plus optional VS Code host smoke test.
- `scripts/`: catalog generation, checks, and development smoke launcher.

## Verification and limitations

See **TEST-REPORT.md** for the checks performed on this delivered build. The credentials posted in conversation were not used. This build was tested offline, not against the user tenant. Offline tests cover representative request and promotion flows; they do not prove every operation is accepted by every tenant. Start with a read-only sandbox connection, then promote a small test transform before using a real configuration set.

## Sources and attribution

- [SailPoint ISC API specifications](https://developer.sailpoint.com/docs/api/)
- [Official API source repository](https://github.com/sailpoint-oss/api-specs), snapshot `a829aeff963ccc11578b7b26ba42c3bccada8b27`.
- [API versioning strategy](https://developer.sailpoint.com/docs/api/api-versioning-strategy/)
- [SP-Config APIs](https://developer.sailpoint.com/docs/api/sp-config/)
- [SaaS configuration management](https://developer.sailpoint.com/docs/extensibility/configuration-management/saas-configuration/)
- [Reference extension](https://github.com/yannick-beot-sp/vscode-sailpoint-identitynow/), reviewed at `88a8681d2239585fe27de59c214447d284b4c1d4`.

Reference templates for transforms, connector rules, roles, and access profiles are bundled in `resources/upstream/` with their MIT license. The extension runtime is independently implemented.  Official SailPoint schemas are redistributed under their MIT license in `resources/SAILPOINT-SPEC-LICENSE.txt`. ISC Workbench's own code is MIT-licensed.

## Resource menus in 0.6

- Sources: Clone, Export Configuration (SP-Config), Delete Resource, account aggregation (optimized/unoptimized), connection test and cluster ping.
- Roles/access profiles: Clone, Export Configuration (SP-Config), Delete Resource, Enable and Disable.
- Transforms/connector rules/workflows: Clone, Export Configuration (SP-Config) and Delete Resource; existing script editing and workflow toggles remain available.
- Other resource rows: Export JSON, Delete Resource (where the API supports direct deletion) and Resource API Actions. Supported configuration collections export SP-Config bundles; other collections export their retrieved inventory as explicitly labelled API JSON.

Clones are created in the same tenant. Roles, access profiles and workflows with an enabled field are cloned disabled. References remain within that tenant. Use environment promotion for cross-tenant changes.

Source cloning uses the selected SOURCE SP-Config export, changes its identity/name, checks name collisions, runs import preview, and imports with backup enabled. It copies the source export, not all associated objects: external password policies, sync groups, connector files and machine subtypes are excluded. Verify credentials and ancillary configuration before using the clone. It is not a full implementation of every upstream source-cloning feature. A failed import can be partial; inspect the tenant before retrying. SP-Config job IDs are retained for Resume or Inspect Job.

Delete Resource requires typing the exact name, an unlocked environment and a documented DELETE endpoint. Tenant deletion is available only through its right-click menu. Lock/unlock stays in the same inline action position.

Provisioning policies are retrieved once without pagination parameters because the observed service repeats its complete policy list when offset is increased. Large inventories retain offset pagination and repeated-page protection.

Write/action results use notifications rather than response JSON tabs. Intentional reads and editing still open documents. Notifications summarize HTTP errors and recognized failure status/error fields; unrecognized vendor-specific result shapes and later background-job failures still require checking tenant task history.

## SP-Config export and clone transport in 0.7

Sources, transforms, roles, access profiles, connector rules, workflows, identity profiles, forms and governance groups export using beta SP-Config, matching the reference extension's service family. A selected item is scoped by its API ID; collections are scoped by configuration type. The downloaded envelope is preserved, including version, tenant, timestamp, options and objects with self/object blocks where returned by the service. A missing or mismatched selected object stops export rather than saving a misleading file. Unsupported configuration types remain explicitly labelled JSON exports.

Source cloning uses this same exporter. It already used SP-Config in 0.6; the raw export menu was a separate path. Version 0.7 aligns cloning with the reference's beta endpoint and serializes multipart options as a JSON text field rather than a file attachment. The data part remains an import.json file and excludeBackup is false. This multipart correction also applies to promotion imports. Preview remains required; preview failure sends no apply request. Import errors distinguish the preview stage from the apply stage, with no automatic retries.

These are verified request-format corrections, not proof of the root cause of a tenant HTTP 500. Live cloning has not been tested from this environment. Check tenant state before retrying an earlier ambiguous import.

Folder hover actions use refresh and plus icons. Their item-specific labels remain available as tooltips and accessible command names. Source cloning still waits for export, preview and import jobs; this patch does not change that sequence.
