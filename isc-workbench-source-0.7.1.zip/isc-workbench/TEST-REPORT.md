# ISC Workbench 0.7.1 — verification record

Build date: 9 September 2026.

## Passed

- JavaScript syntax checks for every runtime module.
- **80 offline automated tests**, using Node's test runner. No tenant credentials or remote writes were used.
- Catalog enumeration: **3,315 versioned operation entries**, including **864 v2026 operations**.
- Every catalog operation resolves, has a response specification, and produces a serializable editable request draft.
- All bundled references resolve across v2026, v2025, v2024, v3, and beta.
- VS Code command registration and representative workflows using a mocked VS Code API.
- OAuth caching/concurrency, credential separation, read-only enforcement, tenant-origin restrictions, blocked credential-header overrides, query serialization, redaction, binary responses, and no automatic write retries.
- Transform editing through a documented update method, stale remote edit rejection, explicit mapping checks, signed object protection, and duplicate-name rejection.
- Promotion target drift rejection, preview-error blocking, exact target confirmation, fresh preview, backup retrieval, and partial-import error reporting.
- Standard VSIX packaging through `@vscode/vsce`, with production dependencies excluded because the runtime has none.

## Save-through regression checks

- Connected resource file URIs restore their environment/resource binding.
- Ctrl+S uses the documented update endpoint without a modal confirmation.
- Two sequential saves handle server-updated timestamps correctly.
- Source PATCH updates change only the edited nested field and do not resend unchanged password fields.
- Environment lock changes update file permissions and block writes from already-open tabs.
- Invalid JSON and rejected writes retain the document and prior baseline.
- Ambiguous network failures block another save until the resource is reopened.
- Source schema/provisioning-policy folders bind the parent source ID.
- API Catalog is opt-in and hidden by default.
- Tenant website addresses are rejected; OAuth failures are logged without secrets.

## Creation, sorting, and identifier regression checks

- Environment and collection ordering; natural alphabetical sort across API pages.
- Cached navigation avoids refetching the whole collection for each displayed page.
- Closed/open lock icon and menu state track read-only/writable environments.
- Source display names and backend-style labels never replace the API ID in a request.
- Missing API IDs cannot fall back to a display name.
- Source creation resolves the exact PAT owner, submits after dialog completion and opens the returned ID.
- Transform creation submits the upstream template after dialog completion without requiring a save.
- Cancelled wizards and locked environments perform no POST.
- Successful creation followed by a delayed/failed GET reports that creation succeeded and does not retry POST.

## Retained creation-receipt and editor checks

- First-save creation and subsequent updates target one resource; restored receipts preserve the actual ID.
- Ambiguous creation receipts survive reopening and prevent repeated POST.
- All 81 source rows in a fixture are visible, including testing-nilay beyond the former 50-row window.
- Find Source opens a cross-version match by ID; no-match reports do not assert deletion.
- Display aliases do not replace API IDs.
- Connector-rule script saves preserve the required ID in PUT bodies.
- Workflow enable/disable follows the current environment lock.

## Not established

- **Actual VS Code desktop/extension-host smoke test:** attempted, but the downloaded Electron host terminated with SIGSEGV in this container. The archive extraction also reported unsupported ownership restoration. No desktop activation or visual QA pass is claimed. The source includes an optional smoke-test launcher and an F5 development configuration for a normal desktop.
- **Live SailPoint integration:** the credentials supplied in conversation were not used. Authentication, endpoint permissions, live request execution, server-side reference resolution, and cross-tenant promotion have not been tested against a real tenant.
- Offline schema coverage does not establish successful execution of every endpoint, service-specific business rules, or feature entitlement.
- Corporate proxy/custom certificate behavior and Windows/macOS host behavior have not been exercised.

## First sandbox check

1. Install the VSIX in VS Code 1.105.0 or later and open ISC Workbench.
2. Add a sandbox environment and run Test Authentication.
3. Browse a source and transform in read-only mode; run a GET API request.
4. Enable writes only in the sandbox, create a disposable static transform through Create Resource, reopen it, edit its value, and press Ctrl+S to save the update.
5. With a second sandbox/UAT tenant, prepare a promotion containing only that transform. Review its candidate and preview result before confirming import.
6. Verify the imported transform and saved import/backup artifacts. Remove disposable test objects explicitly when finished.

## Reproduce offline checks

```sh
npm ci
npm run check
npm test
npm run package
```

Catalog source commit: `a829aeff963ccc11578b7b26ba42c3bccada8b27`.

## Additional 0.5 checks

- Short pages continue using received-record offsets; reported total count avoids extra requests.
- Repeated pages are rejected rather than duplicated.
- 404 fallback binds resource editors to the successful version.
- 403 returns access diagnostics without fallback.
- Unoptimized aggregation sends multipart disableOptimization=true with the actual source ID.
- Locked source actions cannot send requests.
- Live endpoint reachability attempt did not complete; the execution environment reported network approval cancellation. Credentials were not sent. No live read/write or aggregation validation is claimed.

## Additional 0.6 checks

- Provisioning-policy retrieval sends no pagination parameters and requests the collection once.
- Failed action payloads and accepted asynchronous jobs create notifications without opening editors or displaying raw error bodies.
- Role clones remove the original ID, retain references and start disabled.
- Resource deletion requires the exact name and uses the API ID.
- Source-clone name collisions stop before export/import.
- Source clone rewrites the selected object's ID/name and performs preview before import.
- Lock commands share one fixed menu group; tenant deletion is not inline.

Source cloning and other new tenant mutations have not been live-tested. This remains a preview build with offline validation, not a production security certification.

## Additional 0.7 checks

- SP-Config export preserves the server envelope and scopes the selected item's ID.
- Collection export scopes type and does not manufacture self metadata.
- Wrong-object exports are rejected.
- Context titles name Sources, Roles, Access Profiles and Provisioning Policies without the product prefix.
- Clone preview 500 is labelled correctly, uses beta, and sends no apply or retry.
- Serialized multipart bytes contain data as import.json and options as a text field, with backup enabled.

HTTP 500 causation and live success remain unverified. Corrected request differences are established by inspection against the supplied reference code and local tests.

## 0.7.1 UI patch verification

Manifest inspection confirms refresh/add icons on typed folder commands, preserving inline groups and descriptive titles. The prior 80-test runtime baseline applies; no runtime code changed in this patch. Syntax and package integrity checked. Actual hover rendering requires desktop VS Code.
